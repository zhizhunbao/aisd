<<<<<<< HEAD
# Cliff Walking Environment

A custom Gymnasium environment implementing the Cliff Walking problem from Sutton & Barto's Reinforcement Learning textbook.
=======
# CliffWalking Environment

Custom Gymnasium environment for CST8509 Lab 2.
>>>>>>> f184147c4bfc15fe6e38241002457bfaa2b4ca4d

## Installation

```bash
pip install -e .
```

## Usage

```python
import gymnasium
import cliffwalking_env

<<<<<<< HEAD
# GridWorld-v0: Basic 5x5 grid environment
env = gymnasium.make("cliffwalking_env/GridWorld-v0", render_mode="human")

# CliffWalking-v0: 12x4 cliff walking environment
env = gymnasium.make("cliffwalking_env/CliffWalking-v0", render_mode="human")

observation, info = env.reset()
for _ in range(1000):
    action = env.action_space.sample()
    observation, reward, terminated, truncated, info = env.step(action)
    if terminated or truncated:
        observation, info = env.reset()
env.close()
```

## Environments

### GridWorld-v0

- 5x5 grid world
- Agent starts at random position
- Goal is at bottom-right corner
- Actions: 0=right, 1=up, 2=left, 3=down

### CliffWalking-v0

- 12x4 grid (12 columns × 4 rows)
- Agent starts at bottom-left (0, 3)
- Goal is at bottom-right (11, 3)
- Cliff: cells (1,3) to (10,3) in the bottom row
- Reward: -1 per step, -100 for falling off cliff

## Author

Peng Wang (041107730)
=======
env = gymnasium.make("cliffwalking_env/CliffWalking-v0", render_mode="human")
observation, info = env.reset()

for _ in range(1000):
    action = env.action_space.sample()
    observation, reward, terminated, truncated, info = env.step(action)
    
    if terminated or truncated:
        observation, info = env.reset()

env.close()
```
>>>>>>> f184147c4bfc15fe6e38241002457bfaa2b4ca4d
