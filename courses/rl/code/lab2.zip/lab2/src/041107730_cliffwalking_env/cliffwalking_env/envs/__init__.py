"""
<<<<<<< HEAD
Environment classes for the cliffwalking_env package.
"""

# 从各环境模块导入环境类
# Import environment classes from their respective modules
from cliffwalking_env.envs.grid_world import GridWorldEnv
=======
CliffWalking Environment Module Initialization
Author: Peng Wang
Student Number: 041107730

Exports the environment classes for external registration.
"""

# ============================================================
# 导出环境类
# Export Environment Classes
# ============================================================

# 导出原始网格世界环境
# Export original GridWorld environment
from cliffwalking_env.envs.grid_world import GridWorldEnv

# 导出定制化悬崖行走环境
# Export customized CliffWalking environment
>>>>>>> f184147c4bfc15fe6e38241002457bfaa2b4ca4d
from cliffwalking_env.envs.cliff_walking import CliffWalkingEnv

# 导出所有环境类
# Export all environment classes
__all__ = ["GridWorldEnv", "CliffWalkingEnv"]
