"""
<<<<<<< HEAD
Cliff Walking Gymnasium Environment Package
Student ID: 041107730

This package provides custom Gymnasium environments for the Cliff Walking problem.
"""

# 导入 gymnasium 的环境注册功能
# Import gymnasium's environment registration function
from gymnasium.envs.registration import register


def register_envs():
    """注册所有环境的入口函数
    Entry function to register all environments"""
    pass


# 注册 GridWorld-v0 环境（基础5x5网格世界）
# Register GridWorld-v0 environment (basic 5x5 grid world)
register(
    id="cliffwalking_env/GridWorld-v0",
    entry_point="cliffwalking_env.envs:GridWorldEnv",
)

# 注册 CliffWalking-v0 环境（12x4悬崖行走）
# Register CliffWalking-v0 environment (12x4 cliff walking)
=======
CliffWalking Environment Package
CST8509 Lab 2 - Gymnasium Environments for Reinforcement Learning
Student ID: 041107730
"""

# 导入gymnasium的注册函数
# Import gymnasium's register function
from gymnasium.envs.registration import register

# 注册GridWorld原始环境（Lab 2 Step 2: Trial Run 使用）
# Register original GridWorld environment (used by Lab 2 Step 2: Trial Run)
register(
    id="cliffwalking_env/GridWorld-v0",
    entry_point="cliffwalking_env.envs:GridWorldEnv",
    max_episode_steps=300,
)

# 注册CliffWalking环境
# Register CliffWalking environment
>>>>>>> f184147c4bfc15fe6e38241002457bfaa2b4ca4d
register(
    id="cliffwalking_env/CliffWalking-v0",
    entry_point="cliffwalking_env.envs:CliffWalkingEnv",
    max_episode_steps=200,
)
