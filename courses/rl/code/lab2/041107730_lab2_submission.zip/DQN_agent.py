"""
CST8509 Lab 2: DQN Agent using Stable-Baselines3
Author: Peng Wang
Student Number: 041107730

Description:
This script demonstrates the usage of a Deep Q-Network (DQN) from the Stable-Baselines3 library
to solve the custom Cliff Walking environment. It includes training, saving, and evaluating
the model using the SB3 API.
"""

# 导入操作系统和环境变量管理库
# Import os and environment variable management libraries
import os
from dotenv import load_dotenv

# 导入 Gymnasium 和 Stable-Baselines3 相关模块
# Import Gymnasium and Stable-Baselines3 modules
import gymnasium as gym
import cliffwalking_env
from stable_baselines3 import DQN
from stable_baselines3.common.evaluation import evaluate_policy

# 加载个人信息
# Load personal information
load_dotenv('.env.local')


def main():
    """主程序：训练并评估 DQN 模型
    Main program: train and evaluate DQN model"""

    # 打印程序标题
    # Print program header
    print("=" * 80)
    print("Step 1: Training DQN Agent with Stable-Baselines3")
    print("=" * 80)
    print(f"Author: {os.getenv('NAME', 'Peng Wang')}")
    print(f"Student Number: {os.getenv('NUMBER', '041107730')}")
    print("-" * 80)

    # 创建实验图像保存目录 (虽然 SB3 内部管理日志，但我们仍需遵守结构)
    # Create directory to save experiment images
    output_dir = 'lab2_images'
    os.makedirs(output_dir, exist_ok=True)

    # 创建训练环境
    # Create training environment
    env = gym.make("cliffwalking_env/CliffWalking-v0", render_mode=None)

    # 初始化 DQN 模型
    # Initialize DQN model
    # 使用 MultiInputPolicy 因为观测值是字典字典 (Dict Observation)
    # Use MultiInputPolicy because observation is a dictionary
    print("Initializing DQN model...")
    model = DQN(
        policy="MultiInputPolicy",
        env=env,
        learning_rate=1e-3,
        buffer_size=10000,
        learning_starts=1000,
        batch_size=32,
        tau=1.0,
        gamma=0.99,
        train_freq=4,
        gradient_steps=1,
        target_update_interval=10,
        exploration_fraction=0.1,
        exploration_initial_eps=1.0,
        exploration_final_eps=0.05,
        verbose=1
    )

    # 开始训练模型
    # Start model training
    print("\nTraining DQN for 10,000 timesteps...")
    model.learn(total_timesteps=10000, log_interval=10)

    # 保存训练好的模型
    # Save the trained model
    model_path = os.path.join(output_dir, 'dqn_cliffwalking')
    model.save(model_path)
    print(f"\nModel saved to: {model_path}")

    # 步骤 2：评估训练好的模型
    # Step 2: Evaluate the trained model
    print("\n" + "=" * 80)
    print("Step 2: Model Evaluation")
    print("=" * 80)
    
    # 重新加载模型以演示加载流程
    # Reload model to demonstrate loading process
    print("Loading model for evaluation...")
    loaded_model = DQN.load(model_path)

    # 使用 SB3 提供的评价函数
    # Use evaluation function provided by SB3
    mean_reward, std_reward = evaluate_policy(loaded_model, env, n_eval_episodes=10)
    print(f"Mean reward: {mean_reward:.2f} +/- {std_reward:.2f}")

    # 运行一次带渲染 可视化 可视化演示
    # Run a visualized demonstration with rendering
    print("\nRunning visual demonstration...")
    render_env = gym.make("cliffwalking_env/CliffWalking-v0", render_mode="human")
    obs, info = render_env.reset()
    
    for _ in range(50):
        # 获得模型预测的动作
        # Get action predicted by the model
        action, _states = loaded_model.predict(obs, deterministic=True)
        # 转换为整数以用作字典键
        # Convert to int to use as dictionary key
        action = int(action)
        obs, reward, terminated, truncated, info = render_env.step(action)
        if terminated or truncated:
            break
    
    render_env.close()
    print("Demonstration finished.")

    # 提交提示
    # Submission Reminder
    print("\n" + "=" * 60)
    print("Reminder: Include comparisons with Q-Learning results in your report.")
    print("=" * 60)


# 程序入口点
# Program entry point
if __name__ == "__main__":
    main()
